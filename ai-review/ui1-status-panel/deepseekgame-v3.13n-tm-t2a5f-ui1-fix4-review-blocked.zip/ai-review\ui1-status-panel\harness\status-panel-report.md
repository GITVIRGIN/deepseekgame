# UI1 Status Panel Harness Report

- total: 18
- passed: 12
- failed: 6
- pageErrors: 0
- consoleErrors: 0

| check | status | error | screenshot |
| --- | --- | --- | --- |
| playwright available | PASS |  |  |
| server started | PASS |  |  |
| chromium launched | PASS |  |  |
| page loaded | PASS |  |  |
| combat entered | PASS |  |  |
| desktop status panel screenshot | PASS |  | ai-review/ui1-status-panel/harness/screenshots/desktop-status-panel.png |
| status bar exists | FAIL |  |  |
| +N exists | FAIL |  |  |
| popover opened | FAIL |  |  |
| mobile status popover screenshot | PASS |  | ai-review/ui1-status-panel/harness/screenshots/mobile-status-popover.png |
| popover has text | FAIL |  |  |
| Esc closes popover | PASS |  |  |
| desktop status popover screenshot | PASS |  | ai-review/ui1-status-panel/harness/screenshots/desktop-status-popover.png |
| mobile endTurn visible | FAIL |  |  |
| hand visible | FAIL |  |  |
| pageErrors = 0 | PASS |  |  |
| consoleErrors = 0 | PASS |  |  |
| server stopped | PASS |  |  |

## Browser Diagnostics

- pageErrors: none
- consoleErrors: none
- requestfailed: none
